const help = (prefix) => { 
	return `
╭══─⊱  ⸨ 𝐼𝑁𝐹𝑂 ⸩  ⊰─══╮
║
┣╾⊱ * UFIL BOT*
┣╾⊱ *1.0*
┣╾⊱ *VERSION : TERMUX*
┣╾⊱ *wa.me/6285641345088*
┣╾⊱ *THANKS TO :*
┣━━━━[ *MASLENT* ]━━━━━
┣━━━━[ *RIZKY* ]━━━━
┣━━━━[ *MHANKBARBAR* ]━━━━━
║
╰══─⊱  ⸨ UFILBOT ⸩  ⊰─══╯
     𝐑𝐮𝐥𝐞𝐬 - 𝐒𝐢𝐦𝐩𝐥𝐞
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
●⧐JANGAN SPAM BOT
●⧐JANGAN CALL.VC BOT
●⧐LANGGAR GW BAND
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
▣═─⊱【 𝑴𝑬𝑵𝑼 𝑺𝑰𝑴𝑷𝑳𝑬 】⊰─══
║
╰─⊱ 
   |─⊱ *${prefix}listmenu*
╭─⊱
║
▣═─⊱【 𝐿𝐼𝑆𝑇 𝑀𝐸𝑁𝑈 】⊰─══
║
╰─⊱ *${prefix}ownermenu*
╭─⊱ *${prefix}adminmenu*
  |─⊱ *${prefix}nsfwmenu*
  |─⊱ *${prefix}funmenu*
  |─⊱ *${prefix}mediamenu*
  |─⊱ *${prefix} makermenu*
  |─⊱ *${prefix}vipmenu [KHUSUS VIP!!]*
  |─⊱ *${prefix}kerangmenu*
╰─⊱ *${prefix}animemenu*
╭─⊱ *${prefix}othermenu*
║
▣═══─⊱【 𝑂𝑇𝐻𝐸𝑅 】⊰─═══
║
╰─⊱ *${prefix}request [teksmu*
╭─⊱ *${prefix}setprefix*
  |─⊱ *${prefix}bugreport [teksmu]*
  |─⊱ *${prefix}listblock*
  |─⊱ *${prefix}iklan*
  |─⊱ *${prefix}runtime*
  |─⊱ *${prefix}info*
  |─⊱ *${prefix}rules*
  |─⊱ *${prefix}tnc*
  |─⊱ *${prefix}cekvip*
  |─⊱ *${prefix}daftarvip*
  |─⊱ *${prefix}addvip*
  |─⊱ *${prefix}dellvip*
  |─⊱ *${prefix}snk*
  |─⊱ *${prefix}darkadmin*
  |─⊱ *${prefix}darkgroup*
  |─⊱ *${prefix}listpremium*
  |─⊱ *${prefix}donate*
╰─⊱ *${prefix}ping*
╭─⊱ *${prefix}owner*
║
▣══─⊱ 【 𝑅𝑈𝑁𝑇𝐼𝑀𝐸 】 ⊰─══
║
╰─⊱ *STATUS BOT: Online*
╭─⊱ BOT ON: *TERGANTUNG OWNER*
║
▣══─ ⸨ U F I L B O T ⸩ ─══▣`
}
exports.help = help
